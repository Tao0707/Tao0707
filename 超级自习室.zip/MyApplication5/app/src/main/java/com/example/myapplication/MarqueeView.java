package com.example.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Nullable;

public class MarqueeView extends androidx.appcompat.widget.AppCompatTextView {

    public MarqueeView(Context context) {
        super(context);
    }

    public MarqueeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MarqueeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean isFocused() {
        return true;
    }
}