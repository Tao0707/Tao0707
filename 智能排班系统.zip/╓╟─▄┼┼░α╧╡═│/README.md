# zhpb_parent

#### 介绍
智慧排版项目开发

项目核心算法设计：林建强、贺子岩、王芃
项目后端：王敬博
项目前端：吴则昊、王敬博

个人博客：http://myblog.coisini.wang/