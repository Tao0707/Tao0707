import Message from './src/main.js';
export default Message;
