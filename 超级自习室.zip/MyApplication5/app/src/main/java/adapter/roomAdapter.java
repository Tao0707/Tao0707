package adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import com.example.myapplication.R;
import com.example.myapplication.room;

import java.util.ArrayList;
import java.util.Arrays;

public class roomAdapter extends BaseAdapter {
    private ArrayList<room>data;
    private ArrayList<room>b_01;
    private ArrayList<room>b_02;
    private ArrayList<room>b_03;
    private ArrayList<room>b_04;
    private ArrayList<room>b_05;
    private Context context;
    public roomAdapter(ArrayList<room> data, ArrayList<room> b_01, ArrayList<room> b_02, ArrayList<room> b_03, ArrayList<room> b_04, ArrayList<room> b_05, Context context) {
        this.data = data;
        this.b_01 = b_01;
        this.b_02 = b_02;
        this.b_03 = b_03;
        this.b_04 = b_04;
        this.b_05 = b_05;
        this.context = context;
    }

    @Override
    public int getCount() {
        int size1=b_01.size();
        int size2=b_02.size();
        int size3=b_03.size();
        int size4=b_04.size();
        int size5=b_05.size();
        int res[]={size1,size2,size3,size4,size5};
        Arrays.sort(res);
        return res[4];
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        System.out.println(data.size()+"传入适配器的数量");
        ViewHolder viewHolder;
        if(view==null)
        {
            viewHolder=new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.activity_classroom_item,viewGroup,false);
            //viewHolder.textView=view.findViewById(R.id.roomid);
            viewHolder.b_01=view.findViewById(R.id.b_01);
            viewHolder.b_02=view.findViewById(R.id.b_02);
            viewHolder.b_03=view.findViewById(R.id.b_03);
            viewHolder.b_04=view.findViewById(R.id.b_04);
            viewHolder.b_05=view.findViewById(R.id.b_05);
            view.setTag(viewHolder);
        }
        else
        {
            viewHolder = (ViewHolder) view.getTag();
        }

                if(b_01.size()-1>=position)
                {
                    viewHolder.b_01.setText(b_01.get(position).getRoomname());
                }
                else
                {
                    viewHolder.b_01.setText("空");
                }
                if(b_02.size()-1>=position)
                {
                    viewHolder.b_02.setText(b_02.get(position).getRoomname());
                }
                else
                {
                    viewHolder.b_02.setText("空");
                }
                if(b_03.size()-1>=position)
                {
                    viewHolder.b_03.setText(b_03.get(position).getRoomname());
                }
                else
                {
                    viewHolder.b_03.setText("空");
                }
                if(b_04.size()-1>=position)
                {
                    viewHolder.b_04.setText(b_04.get(position).getRoomname());
                }
                else
                {
                    viewHolder.b_04.setText("空");
                }
                if(b_05.size()-1>=position)
                {
                    viewHolder.b_05.setText(b_05.get(position).getRoomname());
                }
                else
                {
                    viewHolder.b_05.setText("空");
                }
        return view;
    }
    private final class ViewHolder{
        TextView textView;
        Button b_01;
        Button b_02;
        Button b_03;
        Button b_04;
        Button b_05;
    }
}
