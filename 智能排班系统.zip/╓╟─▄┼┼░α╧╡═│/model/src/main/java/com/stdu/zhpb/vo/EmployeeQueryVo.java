package com.stdu.zhpb.vo;

import lombok.Data;

@Data
//员工查询VO
public class EmployeeQueryVo {

    private String name;

    private String email;

    private String store;

    private String storeId;




}
