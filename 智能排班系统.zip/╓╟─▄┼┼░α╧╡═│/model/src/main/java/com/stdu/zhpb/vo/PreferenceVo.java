package com.stdu.zhpb.vo;

import lombok.Data;

/**
 * @description:
 * @author: w_jingbo
 * @date: 2023/4/10
 * @Copyright: 博客：http://coisini.wang
 */
@Data
public class PreferenceVo {

    private String store;


}
