package service;

import bean.Brand;
import bean.Pagebean;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface Brandservice {
    //查询所有
    List<Brand> selectAll();

    //添加
    void add(Brand brand);

    //单一删除
    void deleteById(int id);

    //批量删除
    void deleteByIds(@Param("ids") int[] ids);

    //修改犯法
    void update(Brand brand);

    //分页查询   currentPage-当前页码  pagesize-每页展示条数
    Pagebean<Brand> selectByPage(int currentPage,int pagesize);


    //分页条件查询
    Pagebean<Brand> selectByPageAndCondition(int currentPage,int pagesize,Brand brand);
}
