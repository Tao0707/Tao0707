package com.entity;

import lombok.Data;

@Data
public class IP {
    public String host1 = "127.0.0.1";
    public String host2 = "127.0.0.1";
    public String host3 = "127.0.0.1";
    public String host4 = "127.0.0.1";
    public String host5 = "127.0.0.1";

}
