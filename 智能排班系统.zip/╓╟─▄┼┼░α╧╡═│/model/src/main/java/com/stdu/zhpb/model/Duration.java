package com.stdu.zhpb.model;

import lombok.Data;

/**
 * @Author 林健强
 * @Date 2023/4/4 15:23
 * @Description: TODO
 */
@Data
public class Duration {
    private String id;
    private String name;
    private String position;
    private double totalDuration;
}
