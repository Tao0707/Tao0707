package com.example.myapplication;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.fragment.app.Fragment;

public class BLOGFragment extends  Fragment {
    private static final String ARG_TEXT = "param1";
    String mTextString;
    private WebView webview;
    View rootView;

    public BLOGFragment() {
        // Required empty public constructor
    }

    public static BLOGFragment newInstance(String param1) {
        BLOGFragment fragment = new BLOGFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TEXT, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mTextString = getArguments().getString(ARG_TEXT);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_b_l_o_g, container, false);
        }
        webview = rootView.findViewById(R.id.blog);
        webview.setWebViewClient(new WebViewClient());
        webview.getSettings().setUserAgentString("电脑");
        webview.getSettings().setJavaScriptEnabled(true);//允许使用js
        webview.getSettings().setDomStorageEnabled(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true); //设置允许JS弹窗
        webview.getSettings().setBuiltInZoomControls(true);
        webview.getSettings().setUseWideViewPort(true);
        webview.getSettings().setDisplayZoomControls(false);
        webview.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if ((i == KeyEvent.KEYCODE_BACK) && webview.canGoBack()) {
                    webview.goBack(); //goBack()表示返回WebView的上一页面
                    return true;
                }
                return false;
            }
        });
        webview.loadUrl("http://82.157.106.56/index.php/index/index/index.html");
        return rootView;
    }
}