package com.service;

import com.pojo.DeptLog;

public interface DeptLogService {

    void insert(DeptLog deptLog);
}
