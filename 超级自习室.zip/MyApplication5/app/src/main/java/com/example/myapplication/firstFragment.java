package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import com.bumptech.glide.Glide;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.Transformer;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;

public class firstFragment extends Fragment {
    private  Toast toast;
    private static final String ARG_TEXT = "param1";
    private ViewPager viewPager;  //轮播图模块
    private Button button1;
    private Button button2;
    private int[] mImg;
    private int[] mImg_id;
    private String[] mDec;
    private ArrayList<ImageView> mImgList;
    private LinearLayout ll_dots_container;
    private TextView loop_dec;
    private int previousSelectedPosition = 0;
    boolean isRunning = false;
    private String mTextString;
    View rootView;
    private Banner banner;
    private List<Integer> image=new ArrayList<>();
    private List<String> title=new ArrayList<>();
    private void initData() {

        image.add(R.drawable.jiaowu);
        image.add(R.drawable.jiaowu);
        image.add(R.drawable.siji);
        image.add(R.drawable.shuoshi);
//        image.add(R.drawable.lb_second);
//        image.add(R.drawable.lb_three);
//        image.add(R.drawable.lb_five);
        title.add("教务系统");
        title.add("教辅系统-需通过VPN内网访问");
        title.add("四六级官网");
        title.add("2022年研究生招生考试");

    }
    private void initView() {

        banner.setIndicatorGravity(BannerConfig.CENTER);

        banner.setImageLoader(new MyImageLoader());

        banner.setImages(image);

        banner.setBannerAnimation(Transformer.Default);

        banner.isAutoPlay(true);

        banner.setBannerTitles(title);

        banner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR_TITLE_INSIDE);

        banner.setDelayTime(2000);

        banner.setOnBannerListener(this::OnBannerClick);

        banner.start();

    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        init();

    }
    public void init()
    {

        button1= getView().findViewById(R.id.h_head);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),VATUU.class);
                startActivity(intent);
            }
        });
        button2=getView().findViewById(R.id.h_yun);
        button2.setOnClickListener(view -> {
            Toast.makeText(getActivity(),"此功能正在开发中，敬请期待!",Toast.LENGTH_SHORT).show();
        });


    }
    public void OnBannerClick(int position) {
        if (position == 0) {
            Intent intent = new Intent(getActivity(), webview.class);
            startActivity(intent);
            System.out.println(position);

        }
        else if(position==1)
        {
            Intent intent = new Intent(getActivity(), webview2.class);
            startActivity(intent);
            System.out.println(position);
        }
        else if(position==2)
        {
            Intent intent = new Intent(getActivity(), webview3.class);
            startActivity(intent);
            System.out.println(position);
        }
        else{
                Intent intent = new Intent(getActivity(), webview4.class);
                startActivity(intent);
                System.out.println(position);
        }


    }


    private class MyImageLoader extends ImageLoader {

        public void displayImage(Context context, Object path, ImageView imageView) {

            Glide.with(context).load(path).into(imageView);

        }
    }
    public firstFragment() {
        // Required empty public constructor
    }



    public static firstFragment newInstance(String param1) {
        firstFragment fragment = new firstFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TEXT, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mTextString = getArguments().getString(ARG_TEXT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.firstfragment, container, false);
            banner = rootView.findViewById(R.id.banner);
            initData();
            initView();
        }
       //实现轮播图
        return rootView;
    }



}