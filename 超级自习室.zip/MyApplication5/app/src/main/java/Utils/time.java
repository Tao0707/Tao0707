package Utils;

import java.util.Calendar;
public class time {
    public static String time() {
        String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
        Calendar calendar = Calendar.getInstance();
        String  week_day= weekDays[calendar.get(Calendar.DAY_OF_WEEK) - 1];
        return week_day;
    }
}