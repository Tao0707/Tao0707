package com.service.impl;

import com.mapper.DeptMapper1;
import com.mapper.EmpMapper1;
import com.pojo.Dept;
import com.pojo.DeptLog;
import com.service.DeptLogService;
import com.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DeptServiceImpl implements DeptService {

    @Autowired
    private DeptMapper1 deptMapper1;
    @Autowired
    private EmpMapper1 empMapper1;
    @Autowired
    private DeptLogService deptLogService;

    //查询部门信息
    @Override
    public List<Dept> list() {
        List<Dept> list = deptMapper1.list();
        return list;
    }

    //删除部门信息
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteDept(Integer id) {
        try {
            //根据部门id删除部门信息
            deptMapper1.deleteDept(id);

            //删除部门下的所有员工信息
            empMapper1.deteleBydeptid(id);
        } finally {
            //不论是否有异常，最终都要执行的代码：记录日志
            DeptLog deptLog = new DeptLog();
            deptLog.setCreateTime(LocalDateTime.now());
            deptLog.setDescription("执行了解散部门的操作，此时解散的是"+id+"号部门");
            //调用其他业务类中的方法
            deptLogService.insert(deptLog);
        }

    }

    //添加部门信息
    @Override
    public void addDept(Dept dept) {
        dept.setCreateTime(LocalDateTime.now());
        dept.setUpdateTime(LocalDateTime.now());
        deptMapper1.AddDept(dept);
    }

    //根据id查询部门信息
    @Override
    public Dept Byid(Integer id) {
        Dept byid = deptMapper1.Byid(id);
        return byid;
    }

    //修改部门数据
    @Override
    public void updateDept(Dept dept) {
        dept.setUpdateTime(LocalDateTime.now());
        deptMapper1.updateDept(dept);
    }
}
