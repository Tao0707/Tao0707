package com.service;

import com.pojo.Dept;
import com.pojo.Emp;
import com.pojo.PageBean;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 员工管理
 */
public interface EmpService {
    //分页查询员工
    PageBean selectEmp(int page, int pageSize, String name, Short gender, LocalDate begin, LocalDate end);

    //根据id删除员工
    void delete(List<Integer> ids);

    //添加员工
    void addEmp(Emp emp);

    //根据id查询员工，数据回显
    Emp Byid(Integer id);

    //更新员工信息
    void updateEmp(Emp emp);

    //员工登录
    public int Login(String username,String password);

    //条件查询
   // public List<Emp> selectCondetion();

}
