package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class BlankFragment2 extends Fragment {

    private static final String ARG_TEXT = "param1";
   TextView b1;
    TextView b2;
    TextView b3;
    TextView b4;
    TextView b5;
    TextView b6;
    TextView b7;
    private String mTextString;
    View rootView;

    public BlankFragment2() {
        // Required empty public constructor
    }

    public static BlankFragment2 newInstance(String param1) {
        BlankFragment2 fragment = new BlankFragment2();
        Bundle args = new Bundle();
        args.putString(ARG_TEXT, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mTextString = getArguments().getString(ARG_TEXT);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_blank2, container, false);
        }
        initView();
        return rootView;
    }
    private void initView() {
        TextView textView = rootView.findViewById(R.id.text);
        b1=rootView.findViewById(R.id.textView5);
        b2=rootView.findViewById(R.id.textView6);
        b3=rootView.findViewById(R.id.textView7);
        b4=rootView.findViewById(R.id.textView8);

        b6=rootView.findViewById(R.id.textView10);
        b7=rootView.findViewById(R.id.textView11);
        b1.setOnClickListener(view -> {
            Toast.makeText(getActivity(),"此功能正在开发中，敬请期待!",Toast.LENGTH_SHORT).show();
        });
        b2.setOnClickListener(view -> {
            Intent intent=new Intent(getActivity(),webview5.class);
            startActivity(intent);
        });
        b3.setOnClickListener(view -> {
            Toast.makeText(getActivity(),"此功能正在开发中，敬请期待!",Toast.LENGTH_SHORT).show();
        });
        b4.setOnClickListener(view -> {
            Toast.makeText(getActivity(),"此功能正在开发中，敬请期待!",Toast.LENGTH_SHORT).show();
        });
        b6.setOnClickListener(view -> {
            Toast.makeText(getActivity(),"此功能正在开发中，敬请期待!",Toast.LENGTH_SHORT).show();
        });
        b7.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), about.class);
            startActivity(intent);
        });
    }
}