package mapper;

import bean.Brand;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface BrandMapper1 {

    //查询所有
    @Select("select * from tb_brand1")
    @ResultMap("brandResultMap1")
    List<Brand> selectAll();

    //添加
    @Insert("insert into tb_brand1 values (null,#{brandName},#{companyName},#{ordered},#{description},#{status})")
    void add(Brand brand);

    //删除
    @Delete(" delete from tb_brand1 where id = #{id} ")
    void deleteById (int id);

    //批量删除
    void deleteByIds(@Param("ids") int[] ids);

    //修改方法
    void update(Brand brand);

    //分页查询
    @Select("select * from tb_brand1 limit #{begin},#{size}")
    @ResultMap("brandResultMap1")
    List<Brand> selectBypage(@Param("begin") int begin,@Param("size")int size);
    //查询总记录数
    @Select("select count(*) from tb_brand1")
    int selectTotalCount();

    //分页条件查询
    List<Brand> selectBypageAndcondition(@Param("begin") int begin,@Param("size")int size,@Param("brand") Brand brand);
    //根据条件查询总记录数
    int selectTotalCountBycondition(Brand brand);
}
