package Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class day {
    public static int day() throws ParseException {
        String string = "2022-05-01";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");//指定格式时间转换
        Date date = simpleDateFormat.parse(string);//转换成日期
        long datetime = date.getTime();//时间转换成毫秒值
        long todaytime = new Date().getTime();//获取当前日期毫秒值
        long Difference = todaytime - datetime;//差值
        int day =(int) (Difference / 1000 / 60 / 60 / 24);
        return day;
    }
}