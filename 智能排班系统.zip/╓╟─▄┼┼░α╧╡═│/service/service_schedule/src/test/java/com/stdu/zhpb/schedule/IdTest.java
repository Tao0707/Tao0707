package com.stdu.zhpb.schedule;

import org.springframework.boot.test.context.SpringBootTest;

/**
 * @description:
 * @author: w_jingbo
 * @date: 2023/4/9
 * @Copyright: 博客：http://coisini.wang
 */
@SpringBootTest
public class IdTest {


}
