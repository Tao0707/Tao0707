package servlet.old;

import bean.Brand;
import com.alibaba.fastjson.JSON;
import service.Brandservice;
import service.impl.Brandserviceimpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;

@WebServlet("/addAllServlet")
public class AddServlet extends HttpServlet {

    Brandservice brandservice = new Brandserviceimpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        String brand = reader.readLine();

        Brand brand1 = JSON.parseObject(brand, Brand.class);

        brandservice.add(brand1);

        response.getWriter().write("1");


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
