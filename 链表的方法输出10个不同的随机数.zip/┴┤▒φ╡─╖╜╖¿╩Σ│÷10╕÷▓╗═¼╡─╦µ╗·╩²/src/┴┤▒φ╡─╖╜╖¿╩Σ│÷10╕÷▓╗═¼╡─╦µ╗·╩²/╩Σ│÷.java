package �����ķ������10����ͬ�������;
import java.util.*;
public class ���
{
    
	public static void main(String[] args) 
	{
		final int P = 6;
		ArrayList<Integer> list = new ArrayList<Integer>();
		Random ran = new Random();
		while(list.size() < P)
		{
			int item = ran.nextInt(P)+1;
			boolean addflag = true;
			for(int i = 0;i<list.size();i++)
			{
				int itemnum = list.get(i);
				if(item == itemnum) 
				{
					addflag = false;
				}
			}
			if(addflag) 
			{
				list.add(item);
			}
		}
		for(int i = 0;i<list.size();i++)
		{
			int itemnum = list.get(i);
			System.out.print(itemnum+" ");
		}
	}
}