package com.service;

import com.pojo.Dept;
import java.util.List;

/**
 * 部门管理
 */
public interface DeptService {
    //查询部门信息
    List<Dept> list();

    //删除部门信息
    void deleteDept(Integer id);

    //添加部门信息
    void addDept(Dept dept);

    //根据id查询部门信息
    Dept Byid(Integer id);

    //修改部门数据
    void updateDept(Dept dept);
}
