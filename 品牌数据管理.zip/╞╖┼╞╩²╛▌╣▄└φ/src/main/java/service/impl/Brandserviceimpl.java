package service.impl;

import bean.Brand;
import bean.Pagebean;
import mapper.BrandMapper1;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import service.Brandservice;
import util.SqlSessionFactoryUtils;

import java.util.List;

public class Brandserviceimpl implements Brandservice {
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    //查询所有
    @Override
    public List<Brand> selectAll() {
        SqlSession sqlSession = factory.openSession();

        BrandMapper1 mapper = sqlSession.getMapper(BrandMapper1.class);

        List<Brand> brands = mapper.selectAll();

        sqlSession.close();

        return brands;

    }

    //添加
    @Override
    public void add(Brand brand) {
        SqlSession sqlSession = factory.openSession();

        BrandMapper1 mapper = sqlSession.getMapper(BrandMapper1.class);

        mapper.add(brand);

        sqlSession.commit();

        sqlSession.close();
    }

    //删除
    @Override
    public void deleteById(int id) {
        SqlSession sqlSession = factory.openSession();

        BrandMapper1 mapper = sqlSession.getMapper(BrandMapper1.class);

        mapper.deleteById(id);

        sqlSession.commit();

        sqlSession.close();
    }

    //批量删除
    @Override
    public void deleteByIds(int[] ids) {
        SqlSession sqlSession = factory.openSession();

        BrandMapper1 mapper = sqlSession.getMapper(BrandMapper1.class);

        mapper.deleteByIds(ids);

        sqlSession.commit();

        sqlSession.close();
    }

    //添加
    @Override
    public void update(Brand brand) {
        SqlSession sqlSession = factory.openSession();

        BrandMapper1 mapper = sqlSession.getMapper(BrandMapper1.class);

        mapper.update(brand);

        sqlSession.commit();

        sqlSession.close();
    }

    //分页查询
    @Override
    public Pagebean<Brand> selectByPage(int currentPage, int pagesize) {
        SqlSession sqlSession = factory.openSession();

        BrandMapper1 mapper = sqlSession.getMapper(BrandMapper1.class);

        //计算开始索引
        int begin = (currentPage - 1) * pagesize;
        //计算查询条目数
        int size = pagesize;

        //查询当前页数据
        List<Brand> rows = mapper.selectBypage(begin, size);
        //查询总记录数
        int totalCount = mapper.selectTotalCount();
        //封装对象
        Pagebean<Brand> pagebean = new Pagebean<>();
        pagebean.setRow(rows);
        pagebean.setTotalCount(totalCount);

        sqlSession.close();
        return pagebean;
    }

    @Override
    public Pagebean<Brand> selectByPageAndCondition(int currentPage, int pagesize, Brand brand) {
        SqlSession sqlSession = factory.openSession();

        BrandMapper1 mapper = sqlSession.getMapper(BrandMapper1.class);

        //计算开始索引
        int begin = (currentPage - 1) * pagesize;
        //计算查询条目数
        int size = pagesize;

        String brandName = brand.getBrandName();
        if(brandName != null && brandName.length()>0){
            brand.setBrandName("%"+brandName+"%");
        }

        String companyName = brand.getCompanyName();
        if(companyName != null && companyName.length()>0){
            brand.setCompanyName("%"+companyName+"%");
        }

        //查询当前页数据
        List<Brand> rows = mapper.selectBypageAndcondition(begin,size,brand);
        //查询总记录数
        int totalCount = mapper.selectTotalCountBycondition(brand);
        //封装对象
        Pagebean<Brand> pagebean = new Pagebean<>();
        pagebean.setRow(rows);
        pagebean.setTotalCount(totalCount);

        sqlSession.close();
        return pagebean;
    }
}
