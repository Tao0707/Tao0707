package com.example.myapplication;

import adapter.zoneadapter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class z extends  Fragment {
    private static final String ARG_TEXT = "param1";
    ArrayList<VideoBrower> data=new ArrayList<>();
    ListView listView;
    String mTextString;
    TextView textView;
    View rootView;

    public z() {
        // Required empty public constructor
    }

    public static z newInstance(String param1) {
        z fragment = new z();
        Bundle args = new Bundle();
        args.putString(ARG_TEXT, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mTextString = getArguments().getString(ARG_TEXT);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.fragment_z, container, false);
        }
        listView=rootView.findViewById(R.id.list);
        for(int i=0;i<=10;i++)
        {
            VideoBrower v=new VideoBrower();
            v.setUsername("周杰伦");
            v.setDate("2022年5月20日-19:00");
            v.setVideoDescripation("#周杰伦演唱会#");
            v.setPosition("河北省石家庄市");
            data.add(v);
        }
        listView.setAdapter(new zoneadapter(data,getContext()));
        return rootView;
    }

}