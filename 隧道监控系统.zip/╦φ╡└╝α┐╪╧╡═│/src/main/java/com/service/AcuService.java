package com.service;

import com.entity.Acu;

import java.util.List;

public interface AcuService {

    //查询Acu设备数据
    public Acu addAcu();

    //测试数据
    public Acu addAcu2();

}
