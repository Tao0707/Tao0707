package com.mapper;

import com.pojo.Emp;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;
import java.util.List;

/**
 * 员工管理
 */
@Mapper
public interface EmpMapper1 {
/*    //查询总记录数
    @Select("select count(*) from emp")
    public long total();

    //查询分页数据
    @Select("select * from emp limit #{begin},#{pageSize}")
    public List<Emp> emps(int begin,int pageSize);*/

    //分页查询
    public List<Emp> list(String name,Short gender,LocalDate begin,LocalDate end);

    //删除
    public void deleteEmp(List<Integer> ids);

    //增加员工
    @Insert("insert into emp(username, name, gender, image, job, entrydate, dept_id, create_time, update_time) VALUES " +
            "(#{username},#{name},#{gender},#{image},#{job},#{entrydate},#{deptId},#{createTime},#{updateTime})")
    public void addEmp(Emp emp);

    //根据id查询员工
    @Select("select * from emp where id=#{id}")
    public Emp byID(int id);

    //修改员工数据
    public void updateEmp(Emp emp);

    //员工登录
    @Select("select * from emp where username = #{username} and password = #{password}")
    public Emp Login(String username, String password);

    //根据部门id删除员工
    @Delete("delete from emp where dept_id = #{dept_id}")
    public void deteleBydeptid(int dept_id);

}
