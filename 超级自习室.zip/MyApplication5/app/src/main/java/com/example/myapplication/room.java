package com.example.myapplication;

public class room {
    private  String roomname;
    private String jc;
    public room(String roomname, String jc) {
        this.roomname = roomname;
        this.jc = jc;
    }

    public String getRoomname() {
        return roomname;
    }

    public void setRoomname(String roomname) {
        this.roomname = roomname;
    }
    public String getJc() {
        return jc;
    }
    public void setJc(String jc) {
        this.jc = jc;
    }


}
