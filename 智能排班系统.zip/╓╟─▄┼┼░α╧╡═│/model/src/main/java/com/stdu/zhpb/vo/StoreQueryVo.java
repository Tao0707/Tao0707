package com.stdu.zhpb.vo;

import lombok.Data;

@Data
public class StoreQueryVo {

    private String name;

    private String address;
}
