package com.stdu.zhpb.schedule.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.stdu.zhpb.model.Forecast;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ForecastMapper extends BaseMapper<Forecast> {
}
