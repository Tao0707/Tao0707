package com.controller;

import com.pojo.Dept;
import com.pojo.Result;
import com.service.DeptService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.ws.Service;
import java.util.List;

/**
 * 部门管理Controller
 */
@Slf4j    // 生成日志
@RequestMapping("/depts")
@RestController
public class DeptController {

    @Autowired
    private DeptService deptService;

    //查询部门
    @GetMapping
    public Result list(){
        log.info("查询所有部门数据");

        List<Dept> Deptlist = deptService.list();
        return Result.success(Deptlist);
    }

    //删除部门
    @DeleteMapping("/{id}")
    public Result deleteDept(@PathVariable Integer id){
        log.info("删除部门");

        deptService.deleteDept(id);
        return Result.success();
    }

    //新增部门
    @PostMapping
    public Result addDept(@RequestBody Dept dept){
        log.info("添加部门:{}",dept);

        deptService.addDept(dept);
        return Result.success();
    }

    //根据id查询部门
    @GetMapping("/{id}")
    public Result selectByid(@PathVariable Integer id){
        log.info("根据id查询部门信息");

        Dept byid = deptService.Byid(id);
        return Result.success(byid);
    }

    //修改部门数据
    @PutMapping
    public Result updateDept(@RequestBody Dept dept){
        log.info("修改部门数据：{}",dept);

        deptService.updateDept(dept);
        return Result.success();
    }

}
