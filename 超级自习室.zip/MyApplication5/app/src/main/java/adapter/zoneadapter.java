package adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;
import com.example.myapplication.R;
import com.example.myapplication.VideoBrower;

import java.util.ArrayList;


public class zoneadapter extends BaseAdapter {
      ArrayList<VideoBrower>data;
    Context context;
    public zoneadapter(ArrayList<VideoBrower> data, Context context) {
        this.data = data;
        this.context = context;
    }
    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        System.out.println(data.size()+"传入适配器的数量");
        ViewHolder viewHolder;
        String username=data.get(i).getUsername();
        String date=data.get(i).getDate();
        String videoDescripation=data.get(i).getVideoDescripation();
        String position=data.get(i).getPosition();
        if(view==null)
        {
            viewHolder=new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.item_zone,viewGroup,false);
           // viewHolder.imageView=view.findViewById(R.id.video_avatar);
            viewHolder.username=view.findViewById(R.id.video_username);
            viewHolder.date=view.findViewById(R.id.video_date);
            viewHolder.descripation=view.findViewById(R.id.video_descripation);
            viewHolder.position=view.findViewById(R.id.video_position);
            view.setTag(viewHolder);
        }
        else
        {
            viewHolder = (zoneadapter.ViewHolder) view.getTag();
        }
            viewHolder.username.setText(username);
            viewHolder.date.setText(date);
            viewHolder.descripation.setText(videoDescripation);
            viewHolder.position.setText(position);

        return view;
    }
    private final class ViewHolder{
ImageView imageView;
TextView username;
TextView date;
TextView descripation;
VideoView video;
TextView position;
    }
}
