package com.controller;

import com.pojo.Emp;
import com.pojo.Result;
import com.service.EmpService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j    // 生成日志
@RestController
public class LoginController {

    @Autowired
    private EmpService empService;

    @PostMapping("/login")
    public Result Login(@RequestBody Emp emp){
        log.info("员工登录:{}",emp);
        int login = empService.Login(emp.getUsername(), emp.getPassword());
        if (login == 1){
            return Result.success();
        }
        else return Result.error("登录失败");
    }
}
