package com.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.mapper.EmpMapper1;
import com.pojo.Dept;
import com.pojo.Emp;
import com.pojo.PageBean;
import com.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class EmpServiceImpl implements EmpService {

    @Autowired
    private EmpMapper1 empMapper1;

    //分页查询员工
    @Override
    public PageBean selectEmp(int page, int pageSize, String name, Short gender, LocalDate begin, LocalDate end) {
/*      int begin = (page-1)*pageSize;

        List<Emp> emps = empMapper1.emps(begin, pageSize);
        long total = empMapper1.total();

        PageBean pageBean = new PageBean();
        pageBean.setTotal(total);
        pageBean.setRows(emps);*/

        PageHelper.startPage(page,pageSize);
        List<Emp> list = empMapper1.list(name, gender, begin, end);
        Page<Emp> P = (Page<Emp>) list;
        PageBean pageBean = new PageBean(P.getTotal(),P.getResult());
        return  pageBean;
    }

    //根据id删除员工
    @Override
    public void delete(List<Integer> ids) {
        empMapper1.deleteEmp(ids);
    }

    //添加员工
    @Override
    public void addEmp(Emp emp) {
        emp.setCreateTime(LocalDateTime.now());
        emp.setUpdateTime(LocalDateTime.now());
        empMapper1.addEmp(emp);
    }

    //根据id查询员工，数据回显
    @Override
    public Emp Byid(Integer id) {
        Emp emp = empMapper1.byID(id);
        return emp;
    }

    //更新员工信息
    @Override
    public void updateEmp(Emp emp) {
        emp.setUpdateTime(LocalDateTime.now());
        empMapper1.updateEmp(emp);
    }

    //员工登录
    @Override
    public int Login(String username, String password) {
        Emp emplogin = empMapper1.Login(username, password);
        if(emplogin != null){
            return 1;
        }
        else return 0;
    }

/*    //条件查询测试
    public List<Emp> selectCondetion(){
        LambdaQueryWrapper<Emp> lqw = new LambdaQueryWrapper<>();

        lqw.lt(Emp::getId,20); //小于
        lqw.gt(Emp::getId,10); //大于

        //lqw.lt(Acu::getId,20).gt(Acu::getId,10);       //并且关系，10到20之间
        //lqw.gt(Acu::getId,20).or().lt(Acu::getId,10);  //或者关系，小于10且大于20

        List<Emp> acus = empMapper.selectList(lqw);
        return acus;
    }*/

}
