package servlet;

import bean.Brand;
import bean.Pagebean;
import com.alibaba.fastjson.JSON;
import service.Brandservice;
import service.impl.Brandserviceimpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

@WebServlet("/Brand/*")
public class BrandServlet extends BaseServlet {
    Brandservice brandservice = new Brandserviceimpl();

    //查询所有方法
    public void selectAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Brand> brands = brandservice.selectAll();

        String jsonString = JSON.toJSONString(brands);

        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);

    }

    //添加方法
    public void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        BufferedReader reader = request.getReader();
        String brand = reader.readLine();

        Brand params = JSON.parseObject(brand, Brand.class);

        brandservice.add(params );

        response.getWriter().write("1");
    }

    //批量删除
    public void deleteByids(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        BufferedReader reader = request.getReader();
        String params = reader.readLine();

        int[] ids = JSON.parseObject(params, int[].class);

        brandservice.deleteByIds(ids);

        response.getWriter().write("1");
    }

    //单一删除
    public void deleteByid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String id1 = request.getParameter("id");
        System.out.println(id1);
        brandservice.deleteById(Integer.valueOf(id1));

        response.getWriter().write("1");
    }

    //修改方法
    public void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        BufferedReader reader = request.getReader();
        String brand = reader.readLine();

        Brand params = JSON.parseObject(brand, Brand.class);

        brandservice.update(params );

        response.getWriter().write("1");
    }

    //分页查询
    public void selectBypage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 1. 接受 当前页码 和 每页展示条数
        String _currentPage = request.getParameter("currentPage");
        String _pagesize = request.getParameter("pagesize");

        int currentPage = Integer.parseInt(_currentPage);
        int pagesize = Integer.parseInt(_pagesize);

        //2. 调用service查询
        Pagebean<Brand> pagebean = brandservice.selectByPage(currentPage,pagesize);


        String jsonString = JSON.toJSONString(pagebean);

        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);

    }

    //分页条件查询
    public void selectBypageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 1. 接受 当前页码 和 每页展示条数
        String _currentPage = request.getParameter("currentPage");
        String _pagesize = request.getParameter("pagesize");

        int currentPage = Integer.parseInt(_currentPage);
        int pagesize = Integer.parseInt(_pagesize);

        //获取查询条件对象
        BufferedReader reader = request.getReader();
        String params = reader.readLine();

        Brand brand = JSON.parseObject(params, Brand.class);
        //2. 调用service查询
        Pagebean<Brand> pagebean = brandservice.selectByPageAndCondition(currentPage,pagesize,brand);


        String jsonString = JSON.toJSONString(pagebean);

        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);

    }
}
