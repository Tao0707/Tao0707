package com.example.myapplication;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class webview extends Activity {
    private WebView webview;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        webview =  findViewById(R.id.webview);
        webview.setWebViewClient(new HelloWebViewClient ());
        webview.getSettings().setUserAgentString("电脑");
        webview.getSettings().setJavaScriptEnabled(true);//允许使用js
        webview.getSettings().setDomStorageEnabled(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true); //设置允许JS弹窗
        webview.getSettings().setBuiltInZoomControls(true);
        webview.getSettings().setUseWideViewPort(true);
        webview.getSettings().setDisplayZoomControls(false);
        webview.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if ((i == KeyEvent.KEYCODE_BACK) && webview.canGoBack()) {
                    webview.goBack(); //goBack()表示返回WebView的上一页面
                    return true;
                }
                return false;
            }
        });
        webview.loadUrl("https://tiedao.vatuu.com/service/login.html?version=2019");
    }

    private class HelloWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
         
    }
    }
                
