package com.example.myapplication;

import Utils.day;
import Utils.time;
import adapter.roomAdapter;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
public class VATUU extends Activity {
    String[] building;
    Spinner spinnerItems;
    TextView textView;
    ListView listView;
    roomAdapter adapter;
    OkHttpClient okHttpClient = new OkHttpClient();
    private Button button1;
    String place;
    String area;
    String  result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_vatuu);
       try {
            initView();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    public void istadapter( ArrayList<room>data) {
   ArrayList<room>b_01=new ArrayList<>();
   ArrayList<room>b_02=new ArrayList<>();
   ArrayList<room>b_03=new ArrayList<>();
   ArrayList<room>b_04=new ArrayList<>();
   ArrayList<room>b_05=new ArrayList<>();
        for(int i=0;i<data.size();i++)
        {
            String jc=data.get(i).getJc();
            if(jc.equals("第1、2节"))
            {
                room room=new room(data.get(i).getRoomname(),data.get(i).getJc());
                b_01.add(room);
            }
            if(jc.equals("第3、4、5节"))
            {
                room room=new room(data.get(i).getRoomname(),data.get(i).getJc());
                b_02.add(room);
            }
            if(jc.equals("第6、7节"))
            {
                room room=new room(data.get(i).getRoomname(),data.get(i).getJc());
                b_03.add(room);
            }
            if(jc.equals("第8、9节"))
            {
                room room=new room(data.get(i).getRoomname(),data.get(i).getJc());
                b_04.add(room);
            }
            if(jc.equals("第10、11、12、13节"))
            {
                room room=new room(data.get(i).getRoomname(),data.get(i).getJc());
                b_05.add(room);
            }
        }
        System.out.println(data.size()+"传入适配器");
        System.out.println(data.size()+"数据源的数量");
        adapter =new roomAdapter(data,b_01,b_02,b_03,b_04,b_05,this);
        listView.setAdapter(adapter);
    }

    private void initView() throws ParseException {
     textView =findViewById(R.id.time);
     listView = findViewById(R.id.classroom);
     String week_day = time.time();//获取当前日期到2022年5月1日过的天数
     int sumday = day.day();
     String week= String.valueOf(11+(int)sumday/7);
     if(week_day.equals("星期日"))
     {
          week= String.valueOf(11+(int)sumday/7-1);
     }
     String time ="第"+week+"周"+"-"+week_day;
     textView.setText(time);
     spinnerItems = findViewById(R.id.room_select);
     //获取array中定义的值
     building= getResources().getStringArray(R.array.building);
        String finalWeek = week;
        spinnerItems.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
         @Override
         public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              place= building[position];
              area="1";
             switch (place){
                 case "基础楼-本部":place="13";break;
                 case "一教-本部":place="31";;break;
                 case "二教-本部":place="7";;break;
                 case "三教-本部":place="21";;break;
                 case "新教A-龙山":place="36";;break;
                 case "新教B-龙山":place="37";;break;
                 case "新教C-龙山":place="38";;break;
                 case "新教D-龙山":place="39";;break;
             }new Thread(new Runnable() {
                 @Override
                 public void run() {
                     System.out.println("执行了okhttp");
                     FormBody formBody = new FormBody.Builder()
                             .add("area",area)
                             .add("building",place)
                             .add("week", finalWeek)
                             .add("xq",week_day)
                             .add("num", String.valueOf(new Date().getTime())).build();
                     //服务器地址String url="http://82.157.106.56:8009/vtServlet";
                     Request request = new Request.Builder().url("http://82.157.106.56:8009/vtServlet")
                             .post(formBody).build();
                     Call call = okHttpClient.newCall(request);
                     try {
                         Response response = call.execute();
                         result = response.body().string();
                         runOnUiThread(new Runnable() {
                             @Override
                             public void run() {
                                 //更改UI；
                                 new Handler().postDelayed(new Runnable() {
                                     @Override
                                     public void run() {
                                         istadapter(parseJSONWithJSONObject(result));
                                     }
                                 },1 *1);  //延迟10秒执行
                             }
                         });
                         System.out.println(result);
                     } catch (IOException e) {
                         e.printStackTrace();
                     }
                 }
             }
             ).start();
         }
         @Override
         public void onNothingSelected(AdapterView<?> parent) {
         }
     });
 }
    public ArrayList<room> parseJSONWithJSONObject(String jsonData) {
        ArrayList<room> data1 =new ArrayList<>();
        try {
            // 把需要解析的数据传入到 JSONArray 对象中
            JSONArray jsonArray = new JSONArray(jsonData);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String roomname = jsonObject.getString("jsmc");
                String jc = jsonObject.getString("jc");
                String id = jsonObject.getString("xh");
                room room = new room(roomname, jc);
                data1.add(room);
                //Log.d("JSONObject解析", "id is " + id);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(data1.size()+"执行了数据解析");
        return data1;
    }
}
